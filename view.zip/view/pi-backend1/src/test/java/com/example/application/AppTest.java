package com.example.application;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AppTest {

    @Test
    public void testExample() {
        // Example test case
        assertEquals(1, 1);
    }
}