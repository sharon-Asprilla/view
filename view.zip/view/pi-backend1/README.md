# pi-backend1

## Project Overview
This project is a web application built using Vaadin, designed to display simple reports of student grades. It features a user-friendly interface for viewing student names, subjects, and grades, along with functionality to generate PDF reports.

## Project Structure
```
pi-backend1
├── src
│   ├── main
│   │   ├── java
│   │   │   └── com
│   │   │       └── example
│   │   │           └── application
│   │   │               └── views
│   │   │                   └── inicio
│   │   │                       └── ReportesView.java
│   │   └── resources
│   │       └── application.properties
│   └── test
│       └── java
│           └── com
│               └── example
│                   └── application
│                       └── AppTest.java
├── pom.xml
├── mvnw
├── mvnw.cmd
├── .mvn
│   └── wrapper
│       ├── maven-wrapper.jar
│       └── maven-wrapper.properties
├── .gitignore
└── README.md
```

## Setup Instructions
1. **Clone the Repository**
   ```bash
   git clone <repository-url>
   cd pi-backend1
   ```

2. **Build the Project**
   Use the Maven wrapper to build the project:
   ```bash
   ./mvnw clean install
   ```

3. **Run the Application**
   Start the application using the Maven wrapper:
   ```bash
   ./mvnw spring-boot:run
   ```

## Usage
- Navigate to `http://localhost:8080/reportes` to access the reports view.
- Use the "Generar Reporte PDF" button to simulate generating a PDF report.

## Dependencies
This project uses the following key dependencies:
- Vaadin for building the user interface.
- Spring Boot for application configuration and management.

## Testing
Unit tests are located in the `src/test/java/com/example/application/AppTest.java` file. Run the tests using:
```bash
./mvnw test
```

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.