package com.example.application.views.inicio;

import java.util.ArrayList;
import java.util.List;

import org.vaadin.lineawesome.LineAwesomeIconUrl;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Menu;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@PageTitle("Estudiantes")
@Route("estudiantes")
@Menu(order = 2, icon = LineAwesomeIconUrl.USERS_SOLID)
public class EstudiantesView extends VerticalLayout {

    private final Grid<Estudiante> grid = new Grid<>(Estudiante.class, false);
    private final List<Estudiante> datos = new ArrayList<>();

    public EstudiantesView() {
        setSizeFull();
        setDefaultHorizontalComponentAlignment(Alignment.CENTER);
        getStyle().set("background-color", "#f5f7fa");

        add(new H2(" Listado de estudiantes y su correo"));

        grid.addColumn(Estudiante::getNombre).setHeader("Nombre");
        grid.addColumn(Estudiante::getEmail).setHeader("Email");
        grid.setWidth("80%");

        // datos de ejemplo
        datos.add(new Estudiante("Juan Pérez", "juan@example.com"));
        datos.add(new Estudiante("María López", "maria@example.com"));
        grid.setItems(datos);

        Button nuevo = new Button("Nuevo estudiante", e -> openForm(null));
        HorizontalLayout actions = new HorizontalLayout(nuevo);
        add(actions, grid);
    }

    private void openForm(Estudiante edit) {
        Dialog dialog = new Dialog();
        TextField nombre = new TextField("Nombre");
        TextField email = new TextField("Email");
        if (edit != null) {
            nombre.setValue(edit.getNombre());
            email.setValue(edit.getEmail());
        }
        Button guardar = new Button("Guardar", ev -> {
            if (edit == null) {
                datos.add(new Estudiante(nombre.getValue(), email.getValue()));
            } else {
                edit.setNombre(nombre.getValue());
                edit.setEmail(email.getValue());
            }
            grid.getDataProvider().refreshAll();
            dialog.close();
        });
        Button cancelar = new Button("Cancelar", ev -> dialog.close());
        FormLayout form = new FormLayout(nombre, email, new HorizontalLayout(guardar, cancelar));
        dialog.add(form);
        dialog.open();
    }

    public static class Estudiante {
        private String nombre;
        private String email;

        public Estudiante() {}
        public Estudiante(String nombre, String email) { this.nombre = nombre; this.email = email; }
        public String getNombre() { return nombre; }
        public void setNombre(String nombre) { this.nombre = nombre; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
    }
}