export const init: () => void;
