import { at as t, as as a } from "./copilot/copilot-_lIGjjDp.js";
export {
  t as _createChildrenDefinitions,
  a as _registerImporter
};
